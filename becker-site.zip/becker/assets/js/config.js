/* Informações comerciais do Restaurante Becker.
   Altere aqui: o site inteiro lê estes valores (links e textos com data-link / data-text). */
window.BECKER = {
  nome: "Restaurante Becker",
  rua: "Rua Três de Outubro, 180",
  bairroCidade: "Centro, Três Passos – RS",
  cep: "98600-000",
  telefone: "(55) 3522-2999",
  telefoneLink: "tel:+555535222999",
  instagram: "https://www.instagram.com/restaurante_becker/",
  maps: "https://www.google.com/maps/search/?api=1&query=Restaurante+Becker+Rua+Tres+de+Outubro+180+Tres+Passos+RS"
  // Horários: propositalmente ausentes até serem confirmados pelo restaurante.
};

(function () {
  var C = window.BECKER || {};
  var doc = document;

  /* Links e textos vindos da configuração central */
  doc.querySelectorAll('[data-link]').forEach(function (el) {
    var k = el.getAttribute('data-link');
    var url = k === 'maps' ? C.maps : k === 'tel' ? C.telefoneLink : k === 'instagram' ? C.instagram : '';
    if (url) el.setAttribute('href', url);
  });
  doc.querySelectorAll('[data-text]').forEach(function (el) {
    var v = C[el.getAttribute('data-text')];
    if (v) el.textContent = v;
  });
  var ano = doc.getElementById('ano');
  if (ano) ano.textContent = new Date().getFullYear();

  /* Header: fundo sólido ao rolar + barra de progresso */
  var header = doc.querySelector('.site-header');
  var bar = doc.querySelector('.progress span');
  function onScroll() {
    var y = window.scrollY || 0;
    header.classList.toggle('is-solid', y > 40);
    var h = doc.documentElement.scrollHeight - window.innerHeight;
    if (bar) bar.style.transform = 'scaleX(' + (h > 0 ? Math.min(y / h, 1) : 0) + ')';
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* Menu mobile */
  var btn = doc.querySelector('.menu-btn');
  var nav = doc.getElementById('nav');
  function setMenu(open) {
    btn.setAttribute('aria-expanded', open);
    btn.setAttribute('aria-label', open ? 'Fechar menu' : 'Abrir menu');
    header.classList.toggle('menu-open', open);
    doc.body.classList.toggle('no-scroll', open);
  }
  btn.addEventListener('click', function () {
    setMenu(btn.getAttribute('aria-expanded') !== 'true');
  });
  nav.addEventListener('click', function (e) { if (e.target.closest('a')) setMenu(false); });
  doc.addEventListener('keydown', function (e) { if (e.key === 'Escape') setMenu(false); });

  /* Revelação durante a rolagem */
  var items = doc.querySelectorAll('.rv');
  if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
    items.forEach(function (el) { io.observe(el); });
  } else {
    items.forEach(function (el) { el.classList.add('in'); });
  }

  /* Cardápio */
  var box = doc.getElementById('menu-list');
  var itens = (window.BECKER_MENU && window.BECKER_MENU.itens) || [];
  function esc(s) { var d = doc.createElement('div'); d.textContent = s; return d.innerHTML; }
  if (!itens.length) {
    box.innerHTML =
      '<p class="menu__empty">As opções do dia variam. Para saber o que está sendo servido, consulte diretamente o restaurante.</p>' +
      '<p><a class="btn" href="' + (C.telefoneLink || '#') + '">Ligar para o restaurante</a></p>';
  } else {
    var groups = {};
    itens.forEach(function (i) { (groups[i.categoria || 'Outros'] = groups[i.categoria || 'Outros'] || []).push(i); });
    var html = '';
    Object.keys(groups).forEach(function (cat) {
      html += '<h3 class="menu__cat">' + esc(cat) + '</h3><ul class="menu__items">';
      groups[cat].forEach(function (i) {
        html += '<li>' + (i.foto ? '<img src="' + esc(i.foto) + '" alt="" loading="lazy" width="120" height="120">' : '') +
          '<div><strong>' + esc(i.nome) + '</strong>' + (i.descricao ? '<p>' + esc(i.descricao) + '</p>' : '') + '</div>' +
          (typeof i.preco === 'number' ? '<span class="menu__price">' + i.preco.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) + '</span>' : '') +
          '</li>';
      });
      html += '</ul>';
    });
    box.innerHTML = html;
  }
})();

/* Dados do cardápio. Vazio de propósito: nenhum prato ou preço foi inventado.
   Enquanto "itens" estiver vazio, o site mostra a orientação para consultar o restaurante.

   Para incluir pratos, adicione objetos assim (preco e foto são opcionais):
   {
     nome: "Nome do prato",
     descricao: "Descrição confirmada pelo restaurante",
     categoria: "Saladas",
     preco: 0.00,            // somente valor confirmado
     foto: "assets/img/arquivo.jpg"
   }
*/
window.BECKER_MENU = {
  itens: []
};

# Site do Restaurante Becker

Site estático (HTML, CSS e JavaScript puros, sem build e sem dependências). Só as fontes vêm do Google Fonts.

## Como executar
Abra `index.html` no navegador, ou, na pasta do projeto: `python3 -m http.server 8000` e acesse http://localhost:8000.

## Fotografias (colocar em `assets/img/`)
| Arquivo | Conteúdo | Uso |
|---|---|---|
| `buffet-assados.jpg` | Buffet com assados e milho | Hero e galeria |
| `salao.jpg` | Salão com mesas e cadeiras | O restaurante |
| `placa-becker.jpg` | Placa "restaurante becker – o sabor lá de casa!" | O restaurante |
| `lombo-glaceado.jpg` | Carne glaceada (vertical) | Experiência |
| `salada-verde.jpg` | Balcão de saladas (vertical) | Experiência e galeria |
| `salada-tomate.jpg` | Tomates com creme (vertical) | Experiência e galeria |
| `fachada.jpg` | Fachada rosa (panorâmica) | Galeria e localização |

Enquanto um arquivo não existir, o site mostra um quadro tracejado com o nome esperado.

## Onde editar
- Contato e links: `assets/js/config.js`
- Cardápio: `assets/js/menu-data.js` (vazio até haver dados confirmados)
- Cores e tipografia: variáveis no topo de `assets/css/styles.css`

## A confirmar com o restaurante
Horários de funcionamento, cardápio e preços, telefone alternativo (55) 99941-1957, e-mail, e se o logotipo da placa pode ser usado em arquivo digital próprio.
